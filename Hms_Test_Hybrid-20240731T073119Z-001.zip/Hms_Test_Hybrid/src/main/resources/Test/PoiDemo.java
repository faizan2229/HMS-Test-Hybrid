/* This is one seperate class that's why public static void main(String[] args) is present it in. 
   It won't be executed through POM.xml . This class is having a method fetchData() which has no relation 
   with the fetchData() method of BasePage class. And it is accessing the excel sheet present 
   in C:\\SeleniumFiles\\Hms_Test_Hybrid\\test.xlsx. It is not accessing the sheet of 
   C:\\Users\\MD GHAREEB NAWAZ\\eclipse-workspace\\Hms_Test_Hybrid\\src\\test\\resources.
 */

package Test;

public class PoiDemo {

	public static void fetchData(String filePath, String SheetName, int columnNumberStart, int columnNumberEnd)
	{
		if(filePath.substring(filePath.length()-4, filePath.length()-1).equals(".xls"))
		{
			System.out.println("xls");
		}
		if(filePath.substring(filePath.length()-4, filePath.length()-1).equals(".lsx"))
		{
			System.out.println("xlsx");
		}
		
		{
			
		}
		
		
		public static void main(String[] args)
		{
			fetchData("C:\\SeleniumFiles\\Hms_Test_Hybrid\\test.xlsx","Sheet1", 0, 2);
		}
	}
}
