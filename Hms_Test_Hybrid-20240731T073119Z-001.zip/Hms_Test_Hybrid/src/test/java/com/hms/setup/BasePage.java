package com.hms.setup;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Parameters;
import java.io.File;
import java.io.FileInputStream;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.AfterClass;

public class BasePage {
  
	private WebDriver driver;
	public static Logger log;
	
	public WebDriver getDriver()
	{
		return driver;	
	}
	
public void initialize(String browser, String url)
{
	String basePath = System.getProperty("user.dir");   //user.dir you give current working directory. you can print it using System.out.println(System.getProperty("user.dir"));

	switch(browser)
	{
	case "IE":
		//code to initialize webdriver instance
		System.setProperty("webdriver.ie.driver", basePath+"\\src\\test\\java\\Driver\\"+"IEDriverServer.exe");
		//System.setProperty("webdriver.ie.driver", "C:\\IEDriverServer.exe");
		driver = new InternetExplorerDriver();
		driver.get(url);
		break;

	case "Firefox":
		//code to initialize webdriver instance
		driver = new FirefoxDriver();
		driver.get(url);
		break;	

	case "Chrome":
		//code to initialize webdriver instance
		ChromeOptions option= new ChromeOptions();
		option.setBinary("C:\\Users\\MD GHAREEB NAWAZ\\AppData\\Local\\Google\\Chrome\\Application\\chrome.exe");
		System.setProperty("webdriver.chrome.driver", basePath+"\\src\\test\\java\\Driver\\"+"chromedriver.exe");
		//System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
		driver = new ChromeDriver(option);
		driver.get(url);
		break;	
		
	default:
		driver = new FirefoxDriver();
		driver.get(url);
	}
}

	@BeforeSuite
	public void logInitialisation() {
		log = Logger.getLogger(getClass());
	}

  @BeforeClass
  @Parameters({"browserName","url"})
  public void setup(String browser, String url1) 
  {
	  initialize(browser, url1);
  }
  
  //Row and column index starts from 0
  public Object[][] fetchData(String filePath, String SheetName, int columnNumberStart, int columnNumberEnd){
	  
	  Object[][] data = null;
	  int noOfrow = -1;
	  int noOfColumns = -1;
	  DataFormatter formatter = new DataFormatter();
	  
	  if(filePath.substring(filePath.length()-3, filePath.length()).equals("lsx")) 
	  {
		  try
		  {
			  FileInputStream f = new FileInputStream(new File(filePath));
			  XSSFWorkbook wb = new XSSFWorkbook(f);
			  //Loading excel sheet
			  XSSFSheet sh = wb.getSheet(SheetName);
			  //identify the no of rows and columns
			  noOfrow = sh.getLastRowNum();
			  //System.out.println(sh.getLastRowNum());					//just for check
			  noOfColumns = (columnNumberEnd - columnNumberStart) + 1;
			  //System.out.println(noOfColumns);						//just for check
			  
			  //Initializing Object array
			  data = new Object[noOfrow][noOfColumns];
			  
			  for(int i=1;i<=noOfrow;i++)
			  {
				  for(int j=columnNumberStart;j<=columnNumberEnd; j++)
				  {
					  Cell cell = sh.getRow(i).getCell(j);
					  data[i-1][j] = formatter.formatCellValue(cell);
					  
					  // System.out.println("data: "+ data[i-1][j]);      //Just for check
				  }
			  }
			  
			  wb.close();
			  
		  }
		  
		  catch(Exception e)
		  {
			 System.out.println(e.getMessage()); 
		  }
		  
	  }
	  
	  else if(filePath.substring(filePath.length()-3, filePath.length()).equals(".xls"))
	  {

		  try
		  {
			  FileInputStream f = new FileInputStream(new File(filePath));
			  HSSFWorkbook wb = new HSSFWorkbook(f);
			  //Loading excel sheet
			  HSSFSheet sh = wb.getSheet(SheetName);
			  //identify the no of rows and columns
			  noOfrow = sh.getLastRowNum();
			  noOfColumns = (columnNumberEnd - columnNumberStart)+1;
			  
			  //Initializing Object array
			  data = new Object[noOfrow][noOfColumns];
			  
			  for(int i=1;i<=noOfrow;i++)
			  {
				  for(int j=columnNumberStart;j<=columnNumberEnd; j++)
				  {
					  Cell cell = sh.getRow(i).getCell(j);
					  System.out.println("i: " + (i-1));
					  System.out.println("j: " + j);
					  data[i-1][j] = formatter.formatCellValue(cell);
				
				  }
			  }
			  
			  wb.close();
			  
		  }
		  
		  catch(Exception e)
		  {
			 System.out.println(e.getMessage()); 
		  }
		  
	    
	  }
	  
	 
	return data;
  }

  @AfterClass
  public void teardown() 
  {
	  driver.quit();
  }

}
