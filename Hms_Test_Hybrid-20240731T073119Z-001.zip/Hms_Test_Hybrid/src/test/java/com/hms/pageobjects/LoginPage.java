package com.hms.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.hms.setup.BasePage;			//to use log reference variable of Base class

//this class is for Signin and return driver to HomeHover, getting title, verifyingtitle
public class LoginPage {

	private WebDriver driver;

	By userId = By.name("userName");
	By password = By.name("password");
	By loginBtn = By.name("login");
	
	public LoginPage(WebDriver driver2) {
		driver = driver2;
	}
	
	public HomeHover Sigin(String userid, String pass)
	{
		HomeHover d1 = null;
		
		try
		{
			driver.findElement(userId).sendKeys(userid);
			BasePage.log.info("Entered username");
			driver.findElement(password).sendKeys(pass);
			BasePage.log.info("Entered password");
			driver.findElement(loginBtn).click();
			BasePage.log.info("Clicked on login button");
			d1 = new HomeHover(driver);
			new WebDriverWait(driver,5).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(d1.SignOutLink));	
		}
		catch(Exception e)
		{
			BasePage.log.error(e.getMessage());
		}
		return d1;

	}
	
	public String getTitle() {
		BasePage.log.info("title of the page fetched: " +driver.getTitle());
		return driver.getTitle();
	}
	
	public boolean verifytitle(String expectedtitle) {
		BasePage.log.info("Title comparison: expected title" +expectedtitle+ " Actual: " +driver.getTitle());
		if (driver.getTitle().equals(expectedtitle))
			return true;
		else 
			return false;
	}
}