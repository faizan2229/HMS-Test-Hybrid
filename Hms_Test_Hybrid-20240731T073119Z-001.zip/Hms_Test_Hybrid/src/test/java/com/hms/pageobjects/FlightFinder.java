package com.hms.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.hms.setup.BasePage;			//to use log reference variable of Base class

public class FlightFinder {

	private WebDriver driver;
	
	String actMessage ="Use our Flight Finder to search for the lowest fare on participating airlines. Once you've booked your flight, don't forget to visit the Mercury Tours Hotel Finder to reserve lodging in your destination city.";
	By webMessageLink = By.xpath("//table[@width='492']/tbody/tr[3]/td/font");
	By SignOutLink = By.linkText("SIGN-OFF");

	public FlightFinder(WebDriver driver2) {
		driver = driver2;
	}
	
	public boolean verifyLogin()

	{
		BasePage.log.info("Flight page message verification");
		
		if(driver.findElement(webMessageLink).getText().toString().contains(actMessage))
		{
			BasePage.log.info("Flight page verification is passed");
			return true;	
		}
		else
		{
			BasePage.log.info("Flight page verification is failed");
			return false;
		}
			
	}
	
	public void logout()
	{
		BasePage.log.info("Click on SIGN-OFF link");
		new WebDriverWait(driver, 10).until(ExpectedConditions.visibilityOfAllElementsLocatedBy(SignOutLink));
		driver.findElement(SignOutLink).click();
	}
}