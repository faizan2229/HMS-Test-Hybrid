package com.hms.pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;


import com.hms.setup.BasePage;				//to use log reference variable of Base class

//this class is for Hover on Home link and return driver to FlightFinder class, getting title, verifyingtitle
public class HomeHover 
{
	private WebDriver driver;
	
	By SignOutLink=By.linkText("SIGN-OFF");
	By myHomeLink = By.linkText("Home");
	By myFlightLink = By.linkText("Flights");
	
	
  public HomeHover(WebDriver driver2) {
		driver = driver2;
	}


  public FlightFinder HomePage() {
	  
	  try
	  {
		  WebElement home = driver.findElement(myHomeLink);
		  BasePage.log.info("Home page image: " + home.getText());
		  
		  Actions action = new Actions(driver);
		  action.moveToElement(home).build().perform();
		  new WebDriverWait(driver, 5000);
		  
		  driver.findElement(myFlightLink).click();
		  BasePage.log.info("Clicked on Link: " + myFlightLink);
		  
	  }
	  catch(Exception e)
	  {
		  BasePage.log.info(e.getMessage());
	  }
	  
	  return new FlightFinder(driver);
	 
	  
	  
	  
  }
}
