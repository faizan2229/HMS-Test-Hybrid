package com.hms.testcase;

import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import com.hms.pageobjects.FlightFinder;
import com.hms.pageobjects.HomeHover;
import com.hms.pageobjects.LoginPage;
import com.hms.setup.BasePage;

public class MercuryreservationTest extends BasePage {
  WebDriver driver;
	
  @BeforeClass
  public void setup()
  {
	  driver = getDriver();
  }
  
  @Test(dataProvider="getData")
  public void Mercuryreservation(String username, String password)
  {
	  LoginPage login = new LoginPage(driver);
	  HomeHover d = login.Sigin(username,password);
	  
	  
	  if(d!=null)
	  {
		FlightFinder myflight = d.HomePage();  
		
		if(myflight.verifyLogin()==true)
		{
			myflight.logout();
		}
		else
		{
			System.out.println("Login failure");
		}
	  }
		  
	  else
		  System.out.println("Login failure");
	  
  }
  
  @DataProvider
  public Object[][] getData()
  {
	  String basePath = System.getProperty("user.dir");
	  Object[][] data=fetchData(basePath +"\\src\\test\\resources\\"+ "test.xlsx", "Sheet1", 0, 1);  //this will call the fetchData() method of BasePage class
	  
	  //this loop is to iterate values of data Object
	  for(int i=0;i<data.length;i++)
	  {
		  for(int j=0;j<data[i].length;j++)
		  {
			  System.out.println("Row: " + i +" Column: " + j);
			  System.out.println("data is: " + data[i][j]);
			  //Instead of above two line we can write one single line as given below
			  //System.out.println("data[" +i+ "]" + "[" +j+ "]: " +data[i][j]);
		  }
	  }
	  return data;
  }
  

}